#!/usr/bin/env python3

"""
test de cec2014
"""


import numpy as np

import cec2014

a = np.zeros(10)

print(a)
print(cec2014.cec14(a,15))
