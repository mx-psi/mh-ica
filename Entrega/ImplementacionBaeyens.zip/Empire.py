class Empire:
  def __init__(self, imper, imper_fitness, col, col_fitness, emp_total_cost):
    self.imperialist = imper
    self.imperialist_fitness = imper_fitness
    self.colonies = col
    self.colonies_fitness = col_fitness
    self.empire_total_cost = emp_total_cost
